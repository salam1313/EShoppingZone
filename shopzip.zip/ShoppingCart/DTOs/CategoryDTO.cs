namespace EshoppingZoneAPI.DTOs
{
    public class CategoryDTO
    {
        public string Name { get; set; } = string.Empty;
    }
}
