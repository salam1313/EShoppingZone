namespace EshoppingZoneAPI.DTOs
{
    public class AddFundsDTO
    {
        public decimal Amount { get; set; }
    }
}
