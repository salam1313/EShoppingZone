namespace EshoppingZoneAPI.DTOs
{
    public class CheckoutDTO
    {
        public string PaymentMethod { get; set; } = "CashOnDelivery";
    }
}
