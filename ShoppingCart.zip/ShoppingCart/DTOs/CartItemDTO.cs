namespace EshoppingZoneAPI.DTOs
{
    public class CartItemDTO
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
