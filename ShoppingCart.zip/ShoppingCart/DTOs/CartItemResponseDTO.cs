namespace EshoppingZoneAPI.DTOs
{
    public class CartItemResponseDTO
    {
        public int CartItemId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public ProductDTO Product { get; set; }
    }
}
