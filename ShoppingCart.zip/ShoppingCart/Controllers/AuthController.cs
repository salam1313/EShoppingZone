using EshoppingZoneAPI.DTOs;
using EshoppingZoneAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EshoppingZoneAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterDTO dto)
        {
            var result = await _authService.Register(dto);

            if (result == "User already exists")
                return Conflict(new { message = result });

            return Ok(new { message = result }); // ✅ Just message, no token
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserLoginDTO dto)
        {
            var token = await _authService.Login(dto);

            if (token == null)
                return Unauthorized(new { message = "Invalid credentials." });

            return Ok(new { token }); // ✅ Token only on login
        }
    }
}
